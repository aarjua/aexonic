-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2022 at 04:59 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movies`
--

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`id`, `movie_id`, `genre`, `created_at`, `created_by`) VALUES
(1, 1, 'Drama', '2022-07-06 11:16:37', 0),
(2, 2, 'Action', '2022-07-06 11:17:10', 0),
(3, 2, 'Crime', '2022-07-06 11:17:10', 0),
(4, 2, 'Drama', '2022-07-06 11:17:20', 0),
(5, 3, 'Action', '2022-07-06 11:18:02', 0),
(6, 3, 'Adventure', '2022-07-06 11:18:02', 0),
(7, 4, 'Drama', '2022-07-06 11:18:40', 0),
(8, 5, 'Drama', '2022-07-06 11:18:40', 0),
(9, 5, 'Romance', '2022-07-06 11:18:55', 0),
(10, 6, 'Action', '2022-07-06 11:19:40', 0),
(11, 6, 'Adventure', '2022-07-06 11:19:40', 0),
(12, 6, 'Drama', '2022-07-06 11:20:07', 0),
(13, 7, 'Action', '2022-07-06 11:20:07', 0),
(14, 7, 'Adventure', '2022-07-06 11:20:25', 0),
(15, 7, 'Drama', '2022-07-06 11:20:25', 0),
(16, 8, 'Action', '2022-07-06 11:20:48', 0),
(17, 8, 'Crime', '2022-07-06 11:20:48', 0),
(18, 8, 'Drama', '2022-07-06 11:21:21', 0),
(19, 9, 'Adventure', '2022-07-06 11:21:21', 0),
(20, 9, 'Drama', '2022-07-06 11:21:39', 0),
(21, 9, 'War', '2022-07-06 11:21:39', 0),
(22, 10, 'Drama', '2022-07-06 11:22:12', 0),
(23, 10, 'Mystery', '2022-07-06 11:22:12', 0),
(24, 11, 'Crime', '2022-07-06 11:22:42', 0),
(25, 11, 'Drama', '2022-07-06 11:22:42', 0),
(26, 11, 'Thriller', '2022-07-06 11:23:08', 0),
(27, 12, 'Mystery', '2022-07-06 11:23:08', 0),
(28, 12, 'Thriller', '2022-07-06 11:23:45', 0),
(29, 13, 'Action', '2022-07-06 11:23:45', 0),
(30, 13, 'Adventure', '2022-07-06 11:24:00', 0),
(31, 13, 'Fantasy', '2022-07-06 11:24:00', 0),
(32, 14, 'Adventure', '2022-07-06 11:24:26', 0),
(33, 14, 'Comedy', '2022-07-06 11:24:26', 0),
(34, 15, 'Drama', '2022-07-06 11:24:50', 0),
(35, 15, 'Romance', '2022-07-06 11:24:50', 0);

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `director` varchar(255) NOT NULL,
  `release_date` date NOT NULL,
  `vote_count` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(1) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) NOT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `name`, `description`, `director`, `release_date`, `vote_count`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'The Shawshank Redemption', 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.', 'Frank Darabont', '2012-07-01', 500, 1, '2022-07-06 11:26:11', 1, '2022-07-06 10:52:46', 0, '2022-07-06 10:52:46', 0),
(2, 'The Dark Knight', 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.', 'Christopher Nolan', '2008-07-02', 750, 1, '2022-07-06 11:26:18', 1, '2022-07-06 10:53:47', 0, '2022-07-06 10:53:47', 0),
(3, 'Inception', 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project and his team to disaster.', 'Christopher Nolan', '2010-09-06', 800, 1, '2022-07-06 11:26:22', 1, '2022-07-06 10:54:47', 0, '2022-07-06 10:54:47', 0),
(4, 'Fight Club', 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.', 'David Fincher', '1999-01-07', 300, 1, '2022-07-06 11:26:29', 1, '2022-07-06 10:55:40', 0, '2022-07-06 10:55:40', 0),
(5, 'Forrest Gump', 'The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.', 'Robert Zemeckis', '1994-03-02', 1250, 1, '2022-07-06 11:26:34', 1, '2022-07-06 10:56:20', 0, '2022-07-06 10:56:20', 0),
(6, 'The Lord of the Rings: The Return of the King', 'Gandalf and Aragorn lead the World of Men against Sauron\'s army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring.', 'Peter Jackson', '2003-04-10', 2050, 1, '2022-07-06 11:26:40', 1, '2022-07-06 10:57:38', 0, '2022-07-06 10:57:38', 0),
(7, 'Gladiator', 'A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.', 'Ridley Scott', '2000-02-12', 1300, 1, '2022-07-06 11:26:47', 1, '2022-07-06 10:58:35', 0, '2022-07-06 10:58:35', 0),
(8, 'Batman Begins', 'After training with his mentor, Batman begins his fight to free crime-ridden Gotham City from corruption.', 'Christopher Nolan', '2005-05-19', 450, 1, '2022-07-06 11:26:54', 1, '2022-07-06 10:59:27', 0, '2022-07-06 10:59:27', 0),
(9, 'Inglourious Basterds', 'In Nazi-occupied France during World War II, a plan to assassinate Nazi leaders by a group of Jewish U.S. soldiers coincides with a theatre owner\'s vengeful plans for the same.', 'Quentin Tarantino', '2009-08-16', 900, 1, '2022-07-06 11:27:04', 1, '2022-07-06 11:02:49', 0, '2022-07-06 11:02:49', 0),
(10, 'The Prestige', 'After a tragic accident, two stage magicians in 1890s London engage in a battle to create the ultimate illusion while sacrificing everything they have to outwit each other.', 'Christopher Nolan', '2006-09-17', 3000, 1, '2022-07-06 11:28:04', 1, '2022-07-06 11:04:03', 0, '2022-07-06 11:04:03', 0),
(11, 'The Departed', 'An undercover cop and a mole in the police attempt to identify each other while infiltrating an Irish gang in South Boston.', 'Martin Scorsese', '2006-09-22', 1400, 1, '2022-07-06 11:27:23', 1, '2022-07-06 11:04:54', 0, '2022-07-06 11:04:54', 0),
(12, 'Shutter Island', 'In 1954, a U.S. Marshal investigates the disappearance of a murderer who escaped from a hospital for the criminally insane.', 'Martin Scorsese', '2010-10-26', 4000, 1, '2022-07-06 11:27:35', 1, '2022-07-06 11:06:11', 0, '2022-07-06 11:06:11', 0),
(13, 'Avatar', 'A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.', 'ames Cameron', '2009-11-19', 5000, 1, '2022-07-06 11:27:41', 1, '2022-07-06 11:07:06', 0, '2022-07-06 11:07:06', 0),
(14, 'Back to the Future', 'Marty McFly, a 17-year-old high school student, is accidentally sent thirty years into the past in a time-traveling DeLorean invented by his close friend, the eccentric scientist Doc Brown.', 'Robert Zemeckis', '1985-04-01', 7000, 1, '2022-07-06 11:27:46', 1, '2022-07-06 11:08:41', 0, '2022-07-06 11:08:41', 0),
(15, 'Titanic', 'A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.', 'James Cameron', '1997-11-12', 9000, 1, '2022-07-06 11:27:56', 1, '2022-07-06 11:09:21', 0, '2022-07-06 11:09:21', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `movies`
-- (See below for the actual view)
--
CREATE TABLE `movies` (
`id` int(11)
,`name` varchar(255)
,`description` longtext
,`director` varchar(255)
,`release_date` date
,`vote_count` int(11)
,`status` int(1)
,`created_at` timestamp
,`created_by` int(1)
,`updated_at` timestamp
,`updated_by` int(11)
,`deleted_at` timestamp
,`deleted_by` int(11)
,`genres` mediumtext
);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `review` text NOT NULL,
  `status` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `movie_id`, `email_id`, `review`, `status`, `created_at`, `created_by`) VALUES
(1, 1, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:31:00', 0),
(2, 2, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:40', 0),
(3, 3, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:44', 0),
(4, 4, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:47', 0),
(5, 5, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:51', 0),
(6, 6, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:54', 0),
(7, 7, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:36:57', 0),
(8, 8, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:00', 0),
(9, 9, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:03', 0),
(10, 10, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:07', 0),
(11, 11, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:11', 0),
(12, 12, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:14', 0),
(13, 13, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:18', 0),
(14, 14, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:21', 0),
(15, 15, 'john@gmail.com', 'Best Movie', 1, '2022-07-06 11:37:24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `date`) VALUES
(1, 'Aarju', 'aarju.a786599@gmail.com', '12345', 1, '2022-07-07');

-- --------------------------------------------------------

--
-- Structure for view `movies`
--
DROP TABLE IF EXISTS `movies`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `movies`  AS SELECT `m`.`id` AS `id`, `m`.`name` AS `name`, `m`.`description` AS `description`, `m`.`director` AS `director`, `m`.`release_date` AS `release_date`, `m`.`vote_count` AS `vote_count`, `m`.`status` AS `status`, `m`.`created_at` AS `created_at`, `m`.`created_by` AS `created_by`, `m`.`updated_at` AS `updated_at`, `m`.`updated_by` AS `updated_by`, `m`.`deleted_at` AS `deleted_at`, `m`.`deleted_by` AS `deleted_by`, `g`.`combinedsolutions` AS `genres` FROM (`movie` `m` left join (select `s`.`movie_id` AS `movie_id`,group_concat(`s`.`genre` separator ',') AS `combinedsolutions` from `genre` `s` group by `s`.`movie_id`) `g` on(`g`.`movie_id` = `m`.`id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `genre`
--
ALTER TABLE `genre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
