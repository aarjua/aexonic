const express = require('express');
const app = express();
const server = require('http').createServer(app);
var cors = require('cors');
const path = require('path');
const port = 3015;
const ipdata = "localhost";
app.use(express.json());
app.use(cors());
const ioserver = server.listen(port);
const io = require('socket.io')(ioserver, {
    cors: { origin: '*' }
});


app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, X-Access-Token, XKey,Authorization, multipart/form-data');
    next();
});

io.on('connection', async (socket) => {
    console.log('\x1b[31m%s\x1b[0m', socket.id);
    socket.on("disconnect", (reason) => {
        console.log('\x1b[32m%s\x1b[0m', reason);
    });
    io.to(socket.id).emit('connectserver', "You are Connect in Socket Successfully");
   
    require('./app')(socket, io, app);
});
console.log('\x1b[33m%s\x1b[0m', "GPSLab (Socket.IO) live on Localhost:" + port + "/APIRoot");