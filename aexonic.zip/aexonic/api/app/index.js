const login = require('../app/Login/login');
const movie = require('./Movies/Movie'); 

module.exports = function (socket, io, app) {
    login(socket, io);
    movie(socket, io);

}