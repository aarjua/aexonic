const Movie = require('./MovieController');
const ß = require('../Login/CheckToken');
const μ = require('microseconds');
module.exports = function (io, socketio) {

    io.on('/allmovies', async (data) => {
        var start = μ.parse(Date.now()).toString();
        var datanew = undefined;
        datanew = await ß(data.token);
        if (datanew != undefined) {
            const resdata = await Movie.allmovies(datanew.Id, io, start);
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("allmovies", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "Login Please",
                code: 400,
                result: "Authorization failed"
            })
        }

    });


    io.on('/moviebyid', async (data) => {
        var start = μ.parse(Date.now()).toString();
        var datanew = undefined;
        datanew = await ß(data.token);
        if (datanew != undefined) {
            const resdata = await Movie.moviebyid(data,datanew.Id, io, start);
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("moviebyid", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "Login Please",
                code: 400,
                result: "Authorization failed"
            })
        }

    });

 
    io.on('/searchmovie', async (data) => {
        var start = μ.parse(Date.now()).toString();
        var datanew = undefined;
        datanew = await ß(data.token);
        if (datanew != undefined) {
            const resdata = await Movie.searchmovie(data, datanew.Id, io, start);
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("searchmovie", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "Login Please",
                code: 400,
                result: "Authorization failed"
            })
        }

    });

   
    io.on('/orderbyvote', async (data) => {
        var start = μ.parse(Date.now()).toString();
        var datanew = undefined;
        datanew = await ß(data.token);
        if (datanew != undefined) {
            const resdata = await Movie.orderbyvote(data, datanew.Id, io, start);
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("orderbyvote", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "Login Please",
                code: 400,
                result: "Authorization failed"
            })
        }

    });

    io.on('/topvote', async (data) => {
        var start = μ.parse(Date.now()).toString();
        var datanew = undefined;
        datanew = await ß(data.token);
        if (datanew != undefined) {
            const resdata = await Movie.topvote(data, datanew.Id, io, start);
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("topvote", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "Login Please",
                code: 400,
                result: "Authorization failed"
            })
        }

    });
}