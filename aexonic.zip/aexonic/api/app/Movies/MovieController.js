const connt = require('../../connection');
const jwt = require('jsonwebtoken');
const Ʈ = require('../Login/Token');
const μ = require('microseconds');

class MovieController {

    allmovies(Id, io, start) {
        return new Promise(async (resolve, reject) => {
            try {
                const queryd = connt.query('select * from users where id = ? and status =1', [Id], async (err1, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "\n" + queryd.sql);
                    if (result.length > 0) {
                        const queryduser = connt.query('select * from movies where status = 1', async (err1, result1) => {
                            console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                            if (result1.length > 0) {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("allmovies", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: true,
                                    message: "Data Fetched Successfully !!!",
                                    code: 200,
                                    result: result1
                                })

                            } else {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("allmovies", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: false,
                                    message: "user not found",
                                    code: 404,
                                    result: {}
                                })
                            }
                        })
                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("allmovies", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Unauthorized user.",
                            code: 404,
                            result: {}
                        })
                    }
                });
            } catch (e) {
                var end = μ.parse(Date.now()).toString();
                io.emit("allmovies", {
                    ApiStart: start,
                    ApiEnd: end,
                    status: false,
                    message: "Error => 1",
                    code: 404,
                    result: {}
                })
            }
        })
    }

    moviebyid(data, Id, io, start) {
        return new Promise(async (resolve, reject) => {
            try {
                var review = "";
                const queryd = connt.query('select * from users where id = ? and status =1', [Id], async (err1, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "\n" + queryd.sql);
                    if (result.length > 0) {
                        const queryduser = connt.query('select * from movies where id =? and status = 1', [data.movie_id], async (err1, result1) => {
                            console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                            if (result1.length > 0) {
                                for (var i = 0; result1.length > i; i++) {

                                    var reviewdata = await this.getreview(result1[i].id);
                                    if (reviewdata.length > 0) {
                                        review = reviewdata[0].review;
                                    } else {
                                        review = "N/A";
                                    }

                                    var finalobj = {
                                        id: result1[0].id,
                                        name: result1[0].name,
                                        description: result1[0].description,
                                        genre: result1[0].genres,
                                        release_date: result1[0].release_date,
                                        review: review,
                                    }

                                }

                                var end = μ.parse(Date.now()).toString();
                                io.emit("moviebyid", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: true,
                                    message: "Data Fetched Successfully !!!",
                                    code: 200,
                                    result: finalobj
                                })

                            } else {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("moviebyid", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: false,
                                    message: "Movie not found",
                                    code: 404,
                                    result: {}
                                })
                            }
                        })
                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("moviebyid", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Unauthorized user.",
                            code: 404,
                            result: {}
                        })
                    }
                });
            } catch (e) {
                var end = μ.parse(Date.now()).toString();
                io.emit("moviebyid", {
                    ApiStart: start,
                    ApiEnd: end,
                    status: false,
                    message: "Error => 1",
                    code: 404,
                    result: {}
                })
            }
        })
    }

    searchmovie(data, Id, io, start) {
        return new Promise(async (resolve, reject) => {
            try {
                const queryd = connt.query('select * from users where id = ? and status = 1', [Id], async (err1, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "\n" + queryd.sql);
                    if (result.length > 0) {
                        var search = '%' + data.genre + '%';
                        const queryduser = connt.query('select * from movies where status = 1 and genres like ? order by release_date', [search], async (err1, result1) => {
                            console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                            if (result1.length > 0) {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("searchmovie", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: true,
                                    message: "Data Fetched Successfully !!!",
                                    code: 200,
                                    result: result1
                                })

                            } else {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("searchmovie", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: false,
                                    message: "user not found",
                                    code: 404,
                                    result: {}
                                })
                            }
                        })
                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("searchmovie", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Unauthorized user.",
                            code: 404,
                            result: {}
                        })
                    }
                });
            } catch (e) {
                var end = μ.parse(Date.now()).toString();
                io.emit("searchmovie", {
                    ApiStart: start,
                    ApiEnd: end,
                    status: false,
                    message: "Error => 1",
                    code: 404,
                    result: {}
                })
            }
        })
    }

    orderbyvote(data, Id, io, start) {
        return new Promise(async (resolve, reject) => {
            try {
                const queryd = connt.query('select * from users where id = ? and status = 1', [Id], async (err1, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "\n" + queryd.sql);
                    if (result.length > 0) {
                        if (data.votetype == 0) {


                            const queryduser = connt.query('select * from movies where status = 1  order by vote_count desc', async (err1, result1) => {
                                console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                                if (result1.length > 0) {
                                    var end = μ.parse(Date.now()).toString();
                                    io.emit("orderbyvote", {
                                        ApiStart: start,
                                        ApiEnd: end,
                                        status: true,
                                        message: "Data Fetched Successfully !!!",
                                        code: 200,
                                        result: result1
                                    })

                                } else {
                                    var end = μ.parse(Date.now()).toString();
                                    io.emit("orderbyvote", {
                                        ApiStart: start,
                                        ApiEnd: end,
                                        status: false,
                                        message: "user not found",
                                        code: 404,
                                        result: {}
                                    })
                                }
                            })
                        } else {

                            const queryduser = connt.query('select * from movies where status = 1  order by vote_count ', async (err1, result1) => {
                                console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                                if (result1.length > 0) {
                                    var end = μ.parse(Date.now()).toString();
                                    io.emit("orderbyvote", {
                                        ApiStart: start,
                                        ApiEnd: end,
                                        status: true,
                                        message: "Data Fetched Successfully !!!",
                                        code: 200,
                                        result: result1
                                    })

                                } else {
                                    var end = μ.parse(Date.now()).toString();
                                    io.emit("orderbyvote", {
                                        ApiStart: start,
                                        ApiEnd: end,
                                        status: false,
                                        message: "user not found",
                                        code: 404,
                                        result: {}
                                    })
                                }
                            })
                        }
                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("orderbyvote", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Unauthorized user.",
                            code: 404,
                            result: {}
                        })
                    }
                });
            } catch (e) {
                var end = μ.parse(Date.now()).toString();
                io.emit("orderbyvote", {
                    ApiStart: start,
                    ApiEnd: end,
                    status: false,
                    message: "Error => 1",
                    code: 404,
                    result: {}
                })
            }
        })
    }

    topvote(data, Id, io, start) {
        return new Promise(async (resolve, reject) => {
            try {
                const queryd = connt.query('select * from users where id = ? and status =1', [Id], async (err1, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "\n" + queryd.sql);
                    if (result.length > 0) {
                        const queryduser = connt.query('select * from movies where status = 1 order by vote_count desc limit 10', async (err1, result1) => {
                            console.log('\x1b[32m%s\x1b[0m', "\n" + queryduser.sql);
                            if (result1.length > 0) {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("topvote", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: true,
                                    message: "Data Fetched Successfully !!!",
                                    code: 200,
                                    result: result1
                                })

                            } else {
                                var end = μ.parse(Date.now()).toString();
                                io.emit("topvote", {
                                    ApiStart: start,
                                    ApiEnd: end,
                                    status: false,
                                    message: "user not found",
                                    code: 404,
                                    result: {}
                                })
                            }
                        })
                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("topvote", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Unauthorized user.",
                            code: 404,
                            result: {}
                        })
                    }
                });
            } catch (e) {
                var end = μ.parse(Date.now()).toString();
                io.emit("topvote", {
                    ApiStart: start,
                    ApiEnd: end,
                    status: false,
                    message: "Error => 1",
                    code: 404,
                    result: {}
                })
            }
        })
    }

    getreview(movieid) {
        return new Promise(async (resolve, reject) => {
            try {

                var qxtp = connt.query("select * from reviews where movie_id= ?", [movieid], async (err, result) => {
                    console.log('\x1b[32m%s\x1b[0m', "Massages Query : ========  " + qxtp.sql);
                    return resolve(result);
                })

            } catch (e) {
                resolve(e);
            }
        })
    }
}
module.exports = new MovieController();