const jwt = require('jsonwebtoken');
const Ʈ = require('./Token');
module.exports = function (tokens) {
    var user = undefined;
    try {
        if (tokens != undefined) {
              console.log('\x1b[32m%s\x1b[0m',"data set ddddd")
            var Tok1, Tok2, Tok3;
            Tok1 = tokens.split('.')[0];
            Tok2 = tokens.split('.')[1];
            Tok3 = tokens.split('.')[2];
            var t1 = Tok1.length;
            var t3 = Tok3.length;
            var t2 = Tok2.length;
            var mytoken = Tok1.slice(0, t1 - 20) + '.' + Tok3.slice(20, t3) + '.' + Tok2.slice(0, t2 - 20);
            var decode = jwt.verify(mytoken, 'aexonic');
            user = decode;
            console.log('\x1b[32m%s\x1b[0m',user)
            return user;
        } else {
            return undefined;
        }
    } catch (error) {
        return undefined;
    }


}



