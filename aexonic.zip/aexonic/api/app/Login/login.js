const jwt = require('jsonwebtoken');
const connt = require("../../connection");
const checkauth = require('../Login/CheckToken')
const μ = require('microseconds');
const Ʈ = require('./Token');
module.exports = function (io, socketio) {
    io.on('/login', (data) => {
        var start = μ.parse(Date.now()).toString();
        var querydata;
        var valuedata;
        if (data.username != undefined) {
            console.log('\x1b[35m%s\x1b[0m', "\n" + data.username);
            querydata = "Select * from users where  email = ? and password = ?";
            var qxtp = connt.query(querydata, [data.username, data.password], (err, rows) => {
                console.log('\x1b[32m%s\x1b[0m', "Massages Query : ========  " + qxtp.sql);
                if (rows != null && rows != "" && rows.length > 0) {
                    const passkey = rows[0].password;
                    console.log('\x1b[32m%s\x1b[0m', passkey, data.password);
                    if (passkey == data.password) {
                        if (rows[0].status == 1) {
                            const user = {
                                Id: rows[0].id,
                                name: rows[0].name,
                                email: rows[0].email,
                                Status: rows[0].status
                            }
                            jwt.sign(user, 'aexonic', { expiresIn: '600000s' }, async (err, token) => {
                          
                                    if (token != null) {
                                        var nToken = await Ʈ.decode(token);
                                        var end = μ.parse(Date.now()).toString();
                                        io.emit("UserDetails", {
                                            ApiStart: start,
                                            ApiEnd: end,
                                            status: true,
                                            message: "User Login Successfully",
                                            code: 200,
                                            result: {
                                                token: nToken,
                                                Id: user.Id,
                                                displayName: user.name,
                                                email: user.email,
                                                Status: user.Status
                                            }

                                        })
                                    } else {
                                        var end = μ.parse(Date.now()).toString();
                                        io.emit("UserDetails", {
                                            ApiStart: start,
                                            ApiEnd: end,
                                            status: false,
                                            message: "Unauthorized",
                                            result: {
                                                err: "ERROR",
                                                code: 401 //Unauthorized
                                            }
                                        })
                                    }
                             
                            });
                        } else {
                            var end = μ.parse(Date.now()).toString();
                            io.emit("UserDetails", {
                                ApiStart: start,
                                ApiEnd: end,
                                status: false,
                                message: "Your user id is blocked By Admin !! Contact and Send Massage",
                                result: {
                                    err: "ERROR",
                                    code: 403 //Not Found
                                }
                            });
                        }

                    } else {
                        var end = μ.parse(Date.now()).toString();
                        io.emit("UserDetails", {
                            ApiStart: start,
                            ApiEnd: end,
                            status: false,
                            message: "Password Not match",
                            result: {
                                err: "ERROR",
                                code: 403 //Not Found
                            }
                        });
                    }
                } else {
                    var end = μ.parse(Date.now()).toString();
                    io.emit("UserDetails", {
                        ApiStart: start,
                        ApiEnd: end,
                        status: false,
                        message: "User Not Found",
                        result: {
                            err: "ERROR",
                            code: 404 //Not Found
                        }
                    });
                }
            });
        } else {
            var end = μ.parse(Date.now()).toString();
            io.emit("UserDetails", {
                ApiStart: start,
                ApiEnd: end,
                status: false,
                message: "check Email . Something went wrong",
                result: {
                    err: "ERROR",
                    code: 202 //Not Found
                }
            });
        }
    })



   

}