const mysql = require('mysql');
var mysqlconnection = mysql.createConnection({
    // Server
    host: "localhost",
    user: "root",
    password: "",
    database: "movies",
    charset : "utf8mb4",
    // =====================================================================
    multipleStatements: true
});

mysqlconnection.connect((err) => {
    if (!err) {
        console.log('\x1b[32m%s\x1b[0m',"connection Done")
    } else {
        console.log('\x1b[32m%s\x1b[0m',"connection Failed\n" + err )
        console.log("ping");
    }
});

module.exports = mysqlconnection;